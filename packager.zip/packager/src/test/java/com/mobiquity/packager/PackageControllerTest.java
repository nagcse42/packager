package com.mobiquity.packager;

import static org.junit.Assert.assertSame;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;

import com.mobiquity.packager.controller.PackageController;

public class PackageControllerTest {
	
	

	@Test
   public void checkControllerDefaultTest() {
	 PackageController packageController  = new PackageController();
	   System.out.println(" Test ..");
	 assertEquals("Hello World...", packageController.getMessage());
   }


}
