package com.mobiquity.packager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PackagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
