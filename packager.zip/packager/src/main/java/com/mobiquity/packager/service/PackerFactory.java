package com.mobiquity.packager.service;

import com.google.common.collect.Multimap;
import com.google.common.collect.TreeMultimap;
import com.mobiquity.packager.exception.APIException;
import com.mobiquity.packager.model.PackageItem;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays; 
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Collectors;

import static java.lang.Double.parseDouble;
import static java.lang.Integer.parseInt;
import static java.lang.Thread.currentThread;
import static java.util.Objects.requireNonNull;

/**
 * Abstract class that act as Template Method pattern. All methods except pack() could be implemented in another
 * different manner in the child class(es)
 */

public class PackerFactory   {
	
	public final Integer MAX_PACKAGE_WEIGHT = 100;
	public final Integer MAX_ITEM_WEIGHT = 100;
	public final Integer MAX_ITEM_COST = 100;
	public final Integer MAX_ITEMS_AMOUNT = 15;

	
/**
 * Main processing method, holds all method calls within.
*
* @param fileName name of file with initial data
* @return string output returned by {@link com.mobiquityinc.packer.PackerTemplate#getOutput(Map)}
* @throws APIException exception related to the wrong initial data format
*/
final String pack(String fileName) throws APIException {
   File file = getFile(fileName);
   Multimap<String, PackageItem> items = getItems(file);
   Map<String, ArrayList<PackageItem>> packs = processItems(items);
   return getOutput(packs);
}

/**
* Method that performs mostly string related transformations. Holds all the logic related to the output data format.
*
* @param packs map with packages as keys and list of items as items in package
* @return string output in proper format
*/
String getOutput(Map<String, ArrayList<PackageItem>> packs) {
   StringBuilder result = new StringBuilder();
   for (String s : packs.keySet()) {
       if (packs.get(s).isEmpty()) result.append("-\n");
       else {
           for (PackageItem item : packs.get(s)) {
               result.append(item.toString()).append(",");
           }
           result.deleteCharAt(result.toString().length() - 1);
           result.append("\n");
       }

   }
   return result.deleteCharAt(result.toString().length() - 1).reverse().append("\n").toString();
}

/**
* Main initial processing method that holds the logic related to the initial transformation and exception handling.
*
* @param file initial data as file
* @return multimap, where keys is package weight and value is list of items that should be filtered
*/
Multimap<String, PackageItem> getItems(File file) {
   Multimap<String, PackageItem> res = TreeMultimap.create();
   try (BufferedReader bufferedReader = new BufferedReader(new FileReader(file))) {
       bufferedReader.lines()
               .forEach(s -> {
                   String[] weightAndRawItems = s.split(":");
                   String weight = weightAndRawItems[0];

                   if (parseInt(weight.trim()) > MAX_PACKAGE_WEIGHT) {
                       //throw new APIException("Package weight limit exceeded.");

                   }

                   String rawItem = weightAndRawItems[1];

                   if (Arrays.stream(rawItem
                           .replaceFirst(" ", "")
                           .split(" ")).count() > MAX_ITEMS_AMOUNT) {
                       //throw new APIException("Items count limit exceeded.");

                   }

                  // res.put(key, value)
                   
               });
   } catch (Exception e) {
       e.printStackTrace();
   }
   
   return res;
}

/**
* Core processing method that holds business logic implementation.
* Filters items that should be packed by item cost and item weight.
*
* @param things multimap from {@link com.mobiquityinc.packer.PackerTemplate#getItems(File)}
* @return map with package weights as key and filtered list of items as value
*/
Map<String, ArrayList<PackageItem>> processItems(Multimap<String, PackageItem> things) throws APIException {

   Map<String, ArrayList<PackageItem>> result = new LinkedHashMap<>();
   Iterable<String> keys = things.keySet();

   for (String key : keys) {
       result.put(key, new ArrayList<>(MAX_ITEMS_AMOUNT));
   }

   for (Map.Entry<String, PackageItem> entry : things.entries()) {
       result.computeIfPresent(entry.getKey(), (s, integers) -> {
    	   PackageItem entryValue = entry.getValue();
           if ((Arrays.stream(integers.toArray())
                   .mapToDouble(value ->
                           ((PackageItem) value).getWeight()).sum() + entryValue.getWeight()) < parseInt(entry.getKey().trim())) {
               integers.add(entryValue);
           }
           return integers;
       });
   }

   return result;
}

/**
* Method that reads file
*
* @param fileName name of file that should be parsed
* @return file object
*/
File getFile(String fileName) {
   ClassLoader classloader = currentThread().getContextClassLoader();

   return new File(requireNonNull(classloader.getResource(fileName)).getFile());
}
}