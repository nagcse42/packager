package com.mobiquity.packager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

/**
 * @PackagerApplication for handling the package preparation
 * @author arjunparitala
 * @Date 23-NOV-2019
 */
@SpringBootApplication
@ComponentScan("com.mobiquity.packager")
public class PackagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(PackagerApplication.class, args);
	}

}
