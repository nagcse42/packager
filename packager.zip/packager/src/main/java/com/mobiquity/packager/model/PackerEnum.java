package com.mobiquity.packager.model;

/**
 * Enum for constants
 * 
 * @author arjunparitala
 *
 */
public enum PackerEnum {
	MAX_PACKAGE_WEIGHT(100), MAX_ITEM_WEIGHT(100), MAX_ITEM_COST(100), MAX_ITEMS_AMOUNT(15);

	public final Integer maxVal;

	private PackerEnum(Integer maxValue) {
		this.maxVal = maxValue;
	}
	
	public Integer maxValue() {
        return maxVal;
    }
}
