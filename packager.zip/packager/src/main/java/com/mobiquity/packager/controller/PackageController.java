/**
 * 
 */
package com.mobiquity.packager.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mobiquity.packager.service.PackageService;

/**
 * @author arjunparitala
 * @Date 23-NOV-2019
 */
@Controller
public class PackageController {
	
	@Autowired
	private PackageService packageService;

	/**
	 * Method for test
	 * @return String = Hello World...
	 */
	@RequestMapping(value = "/")
	@ResponseBody
	public String getMessage() {
		return "Hello World......";
	}
	
	/**
	 * Method for preparing the package from list of packages in the file
	 * @param packageFilePath
	 * @return
	 */
	@RequestMapping(value = "/preparePackage", method=RequestMethod.POST)
	@ResponseBody
	public String preparePackage(@RequestParam("packageFilePath") String packageFilePath) {
		return this.packageService.processPackage(packageFilePath);
	}
	
}
