/**
 * 
 */
package com.mobiquity.packager.service;

import org.springframework.stereotype.Service;

/**
 * @author arjunparitala
 * @Date 23-NOV-2019
 *  This service is to handle the package preparation
 */

@Service
public class PackageService {

	/**
	 * This method will take file path as parameter and read the packages from that file
	 * @param packageFilePath
	 * @return the prepared package details
	 */
	public String processPackage(String packageFilePath) {
		 String packageDetails = "";
		 
		 return packageDetails;
	}
	
}
